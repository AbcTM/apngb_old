var searchData=
[
  ['default_5fframe_5fdenominator',['DEFAULT_FRAME_DENOMINATOR',['../namespaceapngasm.html#a867b3acbcc2624faf6b3e82732110594',1,'apngasm']]],
  ['default_5fframe_5fnumerator',['DEFAULT_FRAME_NUMERATOR',['../namespaceapngasm.html#a5b334b6957e14291ff8f76cab562f60f',1,'apngasm']]]
];
