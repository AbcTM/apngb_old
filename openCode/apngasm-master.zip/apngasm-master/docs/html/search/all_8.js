var searchData=
[
  ['version',['version',['../classapngasm_1_1APNGAsm.html#ac021e490af5e73353d1efbc5c1216637',1,'apngasm::APNGAsm']]]
];
